package util;

import java.sql.*;
import java.util.ArrayList;

public class JDBC {
    private java.sql.Connection connection = null;
    private Statement statement = null;
    private ResultSet resultSet = null;
    private PreparedStatement preparedStatement = null;

    public Connection getConnection(String username, String password) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://e62650-mysql.services.easyname.eu:3306/u89791db1?" +
                    "user=" + username + "&password=" + password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public ResultSet getResultSet(Connection connection, String sql) throws SQLException {
        statement = connection.createStatement();
        return statement.executeQuery(sql);

    }

    public void insertMultiple(Connection connection, String sql, ArrayList<User> list) throws SQLException {
        preparedStatement = connection.prepareStatement(sql);

        for (User rezepts : list) {
            preparedStatement.setString(1, rezepts.getName());
            preparedStatement.setString(2, String.valueOf(rezepts.getUUID()));
            preparedStatement.addBatch();
        }

        preparedStatement.executeBatch();


    }

    public void executeSQL(Connection connection, String sql) throws SQLException {
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeUpdate();
    }

    public void close() {
        try {
            if (resultSet != null) {
                resultSet.close();
            }

            if (statement != null) {
                statement.close();
            }

            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}