package util;

import java.io.Serializable;

public class User implements Serializable {
    private int id;
    private String name;
    private String uuid;

    public User(String name, String uuid) {
        setName(name);
        setUuid(uuid);
    }

    public User(int id, String name, String uuid) {
        setId(id);
        setName(name);
        setUuid(uuid);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUUID() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        User rezept = (User) o;

        return uuid != null ? uuid.equals(rezept.uuid) : rezept.uuid == null;
    }

    @Override
    public int hashCode() {
        return uuid != null ? Integer.parseInt(uuid.toString()) : 0;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", timestamp=" + uuid +
                '}';
    }
}