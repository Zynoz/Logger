package test;

import util.JDBC;
import util.User;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;

public class Main {

    private static Connection connection;
    private static JDBC jdbc = new JDBC();

    public static void main(String[] args) {

        connection = jdbc.getConnection("u89791db1", "Ma1997xi!");
        try {
            writeResultSet(jdbc.getResultSet(connection, "SELECT * FROM Rezepte"));
        } catch (SQLException e) {
            e.printStackTrace();
        }

        test();

        try {
            writeResultSet(jdbc.getResultSet(connection, "SELECT * FROM Rezepte"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        jdbc.close();
    }

    private static void writeResultSet(ResultSet resultSet) throws SQLException {
        if (resultSet != null) {
            System.out.println("Output: \n");
            while (resultSet.next()) {
                User rezept = new User(resultSet.getInt("id"), resultSet.getString("name"), resultSet.getString("uuid"));
                System.out.println(rezept.toString());
            }
        } else {
            System.err.println("ResultSet is null");
        }
    }

    private static void test() {
        ArrayList<User> rezepte = new ArrayList<>();
        User user1 = new User("asdf", UUID.randomUUID().toString());
        User user2 = new User("asdf", UUID.randomUUID().toString());
        User user3 = new User("asdf", UUID.randomUUID().toString());
        User user4 = new User("asdf", UUID.randomUUID().toString());
        User user5 = new User("asdf", UUID.randomUUID().toString());

        rezepte.add(user1);
        rezepte.add(user2);
        rezepte.add(user3);
        rezepte.add(user4);
        rezepte.add(user5);

        try {
            jdbc.insertMultiple(connection, "INSERT INTO Rezepte (name, uuid) VALUES (?, ?)", rezepte);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}